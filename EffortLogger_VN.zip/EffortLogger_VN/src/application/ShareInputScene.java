package application;

import javafx.stage.Stage;
import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;

//Author: Elver Mojica
//scene controller for ShareUserStory.fxml
//Aligns with class design
public class ShareInputScene {
	@FXML
    private Label range;
	@FXML
    private Label simaverage;
    @FXML
    private Label average;
    @FXML
    private Label high;			//variables to affect the SharUserStory.fxml
    @FXML
    private Label low;
    @FXML
    private Label shareResult;
    private Stage stage;
	private Scene scene;
	private Login login1 = new Login();
	@FXML
	private Label identityField;
	@FXML
	private Label roleField;
	@FXML
	private Label rejectEmployee;
	@FXML
	private TextField useridField;
	@FXML
	private PasswordField passwordField;
    
	public void setLogin(Login login)
	{
		login1.setUserID(login.getUserID());
		login1.setRole(login.getRole());
		
//		System.out.println("User ID: " + login.getUserID());
//		System.out.println("Password: " + login.getPassword());
//		System.out.println("Role: " + login.getRole());
	}
    //goes back to mainline effortlogger when done
	public void switchToMain(ActionEvent event) throws IOException {
		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("EffortLogger.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(fxmlLoader.load(), 600, 400);
		stage.setTitle("EffortLogger");
		
		EffortLoggerController control = fxmlLoader.getController();
		control.setLogin(login1);
		stage.setScene(scene);
		stage.show();
	}
	
    private static ArrayList<String> readFile(String fileNameStr)
    {
        ArrayList<String> arrayList = null;        
        try 
        {
        	Scanner inFile = new Scanner(new FileReader (fileNameStr));
           
        
            arrayList = new ArrayList<>(); //reads the text file into an arraylist for later use 

            while (inFile.hasNextLine() == true)		//reads in a line by line basis
            {
                arrayList.add(inFile.nextLine());
            }
        }
        catch (Exception error)
        {
            System.out.println ("ERROR: could not read file.");
            
            error.printStackTrace();
        }        
        
        return arrayList;        
    }
	
	@FXML
    public void shareResult(ActionEvent event) {
    	ArrayList<String> data = new ArrayList<>();
        data = readFile("UserStory.txt");
        if(data.size() <= 49) { //checks if there are at least 5 entries to show results
        	shareResult.setText("Need 5 or more entires to ensure anonymity");
        }else {
        	shareResult.setText("Results are now shown");
        	int trav = 3; //getting all relevances value
        	ArrayList<Integer> intdata = new ArrayList<>();
        	int min = 10;
        	int minpos = 0;
        	int max = -1;
        	int maxpos = 0;
        	double aver = 0;
        	while(trav <= data.size()) {
        		intdata.add(Integer.parseInt(data.get(trav)));		//puts all relavance data into one seperate arraylist
        		trav = trav + 10;
        	}
        	for(int e = 0; e < intdata.size(); e++) {
        		if(intdata.get(e) < min) {			//finds the min value and its postion in the arraylist
        			min = intdata.get(e);
        			minpos = e;
        		}
        		if(intdata.get(e) > max) {			//fins the max value and its postion in the arraylist
        			max = intdata.get(e);
        			maxpos = e;
        		}
        		aver = intdata.get(e) + aver;
        		
        	}
        	aver = aver/intdata.size();
        	average.setText(String.valueOf(aver));  //prints out average
        	
        	//printing out the simple average
        	aver = 0;
        	for(int e = 0; e < intdata.size(); e++) {		//calculates average of the relevance based without the max and min values 
        		if(e == maxpos || e == minpos) {
        			
        		}else {
        			aver = aver + intdata.get(e);
        		}
        	}
        	String ran = String.valueOf(min) + " - " + String.valueOf(max);
        	range.setText(ran);
        	high.setText(data.get(maxpos*10));			//prints out results onto the mainscreen for user to see
        	low.setText(data.get(minpos*10));
        	
        	System.out.println(aver + " " + (intdata.size()-2));
        	aver = aver/(intdata.size()-2);
        	
        	simaverage.setText(String.valueOf(aver));  //prints out average without the max and min
        	
        	for (String s :data)			//prints out the file for testing purposes
            {						
                System.out.println(s);
            }			
        }
    	
    }
}
