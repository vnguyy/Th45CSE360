package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.*;
import javafx.scene.control.*;

public class DisplayController {

	@FXML
	private Label userid;
	@FXML
	private Label password;
	@FXML
	private Label role;
	@FXML
	private Button logoutBtn;
	
	public void setLogin(Login login)
	{
		userid.setText("User ID: " + login.getUserID());
		password.setText("Password: " + login.getPassword());
		role.setText("Role: " + login.getRole());
		System.out.println("User ID: " + login.getUserID());
		System.out.println("Password: " + login.getPassword());
		System.out.println("Role: " + login.getRole());
	}
	
	public void submitLogout(ActionEvent event) throws IOException {
		Main m = new Main();
		m.changeScene("/LogInScreen.fxml");
	}
}
