package application;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.Node;
import javafx.stage.Stage;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import java.io.IOException;

public class LoginController {
	private Scene scene;
	private Stage stage;
	private Login login = new Login();
	boolean checker = false;
	boolean rolecheck = false;
	
	@FXML
	private TextField useridField;
	@FXML
	private PasswordField passwordField;
	@FXML
	private TextField roleField;
	@FXML
	private Label loginError;
	@FXML
	private Label roleError;
	
	public void submitLogin(ActionEvent event) throws IOException
	{
		checker = checkLogin();

		if (checker == true)
		{
		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("EffortLogger.fxml"));
		login.setUserID(useridField.getText());
		login.setPassword(passwordField.getText());
		login.setRole(roleField.getText());
		
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(fxmlLoader.load(), 600, 400);
		stage.setTitle("EffortLogger");
		
		EffortLoggerController control = fxmlLoader.getController();
		control.setLogin(login);
		stage.setScene(scene);
		stage.show();
		}
	}
	
	public boolean checkRole() throws IOException
	{
		//Main m = new Main();
		if (roleField.getText().compareTo("Employee") == 0 || roleField.getText().compareTo("Employer") == 0 || roleField.getText().compareTo("Supervisor") == 0) {
			return true;
		} else {
			roleError.setText("{Employee, Employer, Supervisor}");
			return false;
		}
	}
	
	public boolean checkLogin() throws IOException
	{
		//Main m = new Main();
		if(useridField.getText().isEmpty() || passwordField.getText().isEmpty() || roleField.getText().isEmpty())
		{
			loginError.setText("Please fill in empty fields.");
			return false;
		} else if (checkRole() == false)
		{
			return false;
		} else {
			return true;
		}
	}
	
}
