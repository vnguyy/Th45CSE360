package application;

import javafx.stage.Stage;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import java.util.ArrayList;
import java.io.FileReader;
import java.util.Scanner;

public class EditUserStory {
	@FXML
    private Label compl;
    @FXML
    private TextField relvance;
    @FXML
    private TextField title;
    private Stage stage;
	private Scene scene;
	private Login login1 = new Login();
	@FXML
	private Label identityField;
	@FXML
	private Label roleField;
	@FXML
	private Label rejectEmployee;
	@FXML
	private TextField useridField;
	@FXML
	private PasswordField passwordField;
	
	public void setLogin(Login login)
	{
		login1.setUserID(login.getUserID());
		login1.setRole(login.getRole());
		
//		System.out.println("User ID: " + login.getUserID());
//		System.out.println("Password: " + login.getPassword());
//		System.out.println("Role: " + login.getRole());
	}
	public void switchToMain(ActionEvent event) throws IOException {
		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("EffortLogger.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(fxmlLoader.load(), 600, 400);
		stage.setTitle("EffortLogger");
		
		EffortLoggerController control = fxmlLoader.getController();
		control.setLogin(login1);
		stage.setScene(scene);
		stage.show();
	}
	
	public void EditResult(ActionEvent event) {
		ArrayList<String> data = new ArrayList<>();
        data = readFile("UserStory.txt");
        ArrayList<String> usertitle = new ArrayList<>();
        int pass = -1;
        int pos = 0;
        int travel = 0;
        String check = "";
        System.out.println(relvance.getText());
        while(travel < data.size()) {   // gets title strings of all inputted values 
        	usertitle.add(data.get(travel));
        	travel = travel + 10;
        }
        travel =0;
		if(relvance.getText() == "" || title.getText() == "") {
			compl.setText("Either Title or Relvance not filled");
		}else {
			//checks if correct value is entered
			if(Integer.parseInt(relvance.getText()) == 0 || Integer.parseInt(relvance.getText()) == 1 || Integer.parseInt(relvance.getText()) == 2 || Integer.parseInt(relvance.getText()) == 3 || Integer.parseInt(relvance.getText()) == 4) {
				pass += 1;
			}
			System.out.println(pass);
			if(pass != -1){
				while(travel < usertitle.size()) {
					check = usertitle.get(travel);
					
					if(check.equals(title.getText()) == true){
						pos = travel;	//checks to see if array has matching user inputted tittle
						travel = 1000;
						
					}else {
						travel = travel + 1;
					}
					
				}
				System.out.println(travel);
				if(travel == 1000) {
					data.set(pos*10+3, relvance.getText());		//does update of relevacnce value
					clearFile();
					writeFile("UserStory.txt", data, usertitle);
					compl.setText("Edit was Successful");
				}else {
					compl.setText("Title is not within the Database"); //title not witihn the arraylist
				}
				
				
			}else {
				compl.setText("Relevance not in range from 0-4");
			}
		}
		
	}

   
    






	private static void writeFile (String fileNameStr, ArrayList<String> arrayList, ArrayList<String> titlelist)
    {
       int travel = 0;
       int pos = 0;
       int poslowtitle = 0;
       int poshightitle = 1;
       int poslowarra = 0;
       int poshigharra = 0;
       int difference = 0;
    	try(FileWriter fw = new FileWriter("UserStory.txt", true);
    		    BufferedWriter bw = new BufferedWriter(fw);
    		    PrintWriter out = new PrintWriter(bw))
    		{
    			for (int e = 0; e < arrayList.size(); e++)
    			{
    				travel = 0;							//writes the information of all data in seperate lines expect the descripition
    				out.format(arrayList.get(e) + "\n");
    				pos++;
    				if(poshightitle >= titlelist.size()) {  //check if outside of range in array
						pos = 5;
					}
    				if(pos == 4) {
    					while(travel< arrayList.size()) {
    						if(arrayList.get(travel).equals(titlelist.get(poslowtitle))) {//finds the location of 1st pointer title
    							poslowarra = travel;
    						}
    						if(arrayList.get(travel).equals(titlelist.get(poshightitle))) {//finds the location of the 2nd pointer title
    							poshigharra = travel;
    						}
    						travel++;
    					}
    					difference = poshigharra - poslowarra+4; //diffeence between both pointers and 4 values 
    					//might need to be changed depending on how user story is done
    					while(difference < 10) {
    						out.format("\n");		//does to ensure that hashmap is kept
    						difference++;
    					}
    					pos = 0;
    					if(poshightitle >= titlelist.size()) {
    						pos = 5;   //checks if out of bounds
    					}else {
    						poshightitle++; //moves one up each pointer
    						poslowarra++;
    					}
    				}
    				
    			}
    			
    		}catch (Exception error)
	        {
	            System.out.println ("ERROR: could not write file.");
	            
	            error.printStackTrace();
	        }
    }


	public static void clearFile()

	{ 
		//clears file
	    try{

	    FileWriter fw = new FileWriter("UserStory.txt", false);

	    PrintWriter pw = new PrintWriter(fw, false);

	    pw.flush();

	    pw.close();

	    fw.close();

	    }catch(Exception exception){

	        System.out.println("Exception have been caught");

	    }

	}


	private static ArrayList<String> readFile(String fileNameStr)
    {
        ArrayList<String> arrayList = null;        
        try 
        {
        	Scanner inFile = new Scanner(new FileReader (fileNameStr));
            arrayList = new ArrayList<>(); //reads the text file into an arraylist for later use 

            while (inFile.hasNextLine() == true)		//reads in a line by line basis
            {
                arrayList.add(inFile.nextLine());
            }
        }
        catch (Exception error)
        {
            System.out.println ("ERROR: could not read file.");            
            error.printStackTrace();
        }           
        return arrayList;        
    }
    
}
