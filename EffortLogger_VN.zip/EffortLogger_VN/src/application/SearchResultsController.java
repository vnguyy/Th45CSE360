package application;

	import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class SearchResultsController {
	
	private Stage stage;
	private Scene scene;
	private Login login1 = new Login();
	@FXML
	private Label identityField;
	@FXML
	private Label roleField;
	@FXML
	private Label rejectEmployee;
	@FXML
	private TextField useridField;
	@FXML
	private PasswordField passwordField;
	
	public void setLogin(Login login)
	{
		login1.setUserID(login.getUserID());
		login1.setRole(login.getRole());
		
//		System.out.println("User ID: " + login.getUserID());
//		System.out.println("Password: " + login.getPassword());
//		System.out.println("Role: " + login.getRole());
	}
	public void switchToMain(ActionEvent event) throws IOException {
		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("EffortLogger.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(fxmlLoader.load(), 600, 400);
		stage.setTitle("EffortLogger");
		
		EffortLoggerController control = fxmlLoader.getController();
		control.setLogin(login1);
		stage.setScene(scene);
		stage.show();
	}
}
