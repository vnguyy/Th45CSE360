package application;

import javafx.stage.Stage;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.Node;

//Author: Vincent Nguyen
//EffortLogger.fxml uses this as a scene controller
//Aligns with class design
public class EffortLoggerController {
	private Stage stage;
	private Scene scene;
	private String role;
	private Login login1 = new Login();
	@FXML
	private Label identityField;
	@FXML
	private Label roleField;
	@FXML
	private Label rejectEmployee;
	@FXML
	private TextField useridField;
	@FXML
	private PasswordField passwordField;
	
	public void setLogin(Login login)
	{
		identityField.setText("'" + login.getUserID() + "'");
		roleField.setText("(" + login.getRole() + ")");
		role = login.getRole();
		login1 = login;
		
		System.out.println("User ID: '" + login.getUserID() + "'");
		//System.out.println("Password: " + login.getPassword());
		System.out.println("Role: " + login.getRole());
	}
	//switches to the main line EffortLogger
	public void switchToMain(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("EffortLogger.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	//switches to login screen
	public void switchToLogIn(ActionEvent event) throws IOException{
		Parent root = FXMLLoader.load(getClass().getResource("/LogInScreen.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	//switches to an fxml to share data wihtin the database
	public void switchToShareResult(ActionEvent event) throws IOException {
		if (role.equals("Supervisor") || role.equals("Employer")) {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/ShareUserStory.fxml"));
			Parent root = loader.load();
			stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			scene = new Scene(root);
			ShareInputScene control = loader.getController();
			control.setLogin(login1);
			stage.setScene(scene);
			stage.show();
		}
	}
	public void switchToSearchResult(ActionEvent event) throws IOException {
		if (role.equals("Supervisor") || role.equals("Employer")) {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SearchResults.fxml"));
			Parent root = loader.load();
			stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			scene = new Scene(root);
			SearchResultsController control = loader.getController();
			control.setLogin(login1);
			stage.setScene(scene);
			stage.show();
		}
		else {
			rejectEmployee.setText("Access Denied. Reason: Role is Employee.");
		}
	}
	//switches to an fxml file to input data for a userstory
	public void switchToCreateUserStory(ActionEvent event) throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/InputUserStory.fxml"));
		Parent root = loader.load();
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		UserInputScene control = loader.getController();
		control.setLogin(login1);
		stage.setScene(scene);
		stage.show();
	}
	
	//switches to an fxml file to show user guide
	public void switchToUserGuide(ActionEvent event) throws IOException{
		FXMLLoader loader = new FXMLLoader(getClass().getResource("UserGuide.fxml"));
		Parent root = loader.load();
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		UserGuideController control = loader.getController();
		control.setLogin(login1);
		stage.setScene(scene);
		stage.show();
	}
	
	//switches to an fxml file to edit data for a userstory
	public void switchToEditUserStory(ActionEvent event) throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("EditUserStory.fxml"));
		Parent root = loader.load();
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		EditUserStory control = loader.getController();
		control.setLogin(login1);
		stage.setScene(scene);
		stage.show();
	}
	
}
