package application;

import javafx.stage.Stage;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

//Author: Jorge Collazo
//Aligns with class design
//InputUserStory.fxml uses this as a scene controller

public class UserInputScene {
	@FXML
    private ComboBox<String> appdomain;
    @FXML
    private TextArea descr;
    @FXML
    private ComboBox<String> prolan;
    @FXML
    private TextField relvance;
    @FXML
    private TextField title;		//variables to interact with InputUserStory.fxml
    private Stage stage;
	private Scene scene;
	private boolean isAccurate = true;
	ObservableList<String> prolanList = FXCollections
    		.observableArrayList("C++","Java");
	ObservableList<String> appdomainList = FXCollections
    		.observableArrayList("Banks","Insurance");
	
	private Login login1 = new Login();
	@FXML
	private Label identityField;
	@FXML
	private Label roleField;
	@FXML
	private Label rejectEmployee;
	@FXML
	private TextField useridField;
	@FXML
	private PasswordField passwordField;
    
	public void setLogin(Login login)
	{
		login1.setUserID(login.getUserID());
		login1.setRole(login.getRole());
		
//		System.out.println("User ID: " + login.getUserID());
//		System.out.println("Password: " + login.getPassword());
//		System.out.println("Role: " + login.getRole());
	}
    //goes back to mainline effortlogger when done
	public void switchToMain(ActionEvent event) throws IOException {
		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("EffortLogger.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(fxmlLoader.load(), 600, 400);
		stage.setTitle("EffortLogger");
		
		EffortLoggerController control = fxmlLoader.getController();
		control.setLogin(login1);
		stage.setScene(scene);
		stage.show();
	}

    
    @FXML
    public void initialize() {
    	prolan.setItems(prolanList);			//puts value into the comboboxes for user to click
    	appdomain.setItems(appdomainList);    	    
    }
    
   
    private static void writeFile (String fileNameStr, ArrayList<String> arrayList)
    {
       int lineCount = 0;
    	try(FileWriter fw = new FileWriter("UserStory.txt", true);
    		    BufferedWriter bw = new BufferedWriter(fw);
    		    PrintWriter out = new PrintWriter(bw))
    		{
    			for (int e = 0; e < arrayList.size(); e++)
    			{
    				if(e < 5) {								//writes the information of all data in seperate lines expect the descripition
    					out.format(arrayList.get(e) + "\n");
    				}else {
    					out.format (arrayList.get(e) + " ");
    				}
    				lineCount++;
    			}
    			while(lineCount < 10) {
    				out.format("\n");
    				lineCount++;
    			}
    		}catch (Exception error)
	        {
	            System.out.println ("ERROR: could not write file.");
	            
	            error.printStackTrace();
	        }
    }
    
    @FXML
    private Label missingInfo;
    @FXML
    private Label userFormErr;
    @FXML
    private Label relevenceErr;
    @FXML
    private Label specialErr;
    @FXML
    private Label titleErr;
    private int errorCount = 0;
    Pattern special = Pattern.compile ("[@#$%&*()_+=|<>?{}\\[\\]~-]");
    
    @FXML
    public void addInfo(ActionEvent event) throws IOException { 
    	//Sets all warning labels to be invisible 
    	missingInfo.setVisible(false);
    	userFormErr.setVisible(false);
    	relevenceErr.setVisible(false);
    	titleErr.setVisible(false);
    	//new strings containing user data
    	String userStory = descr.getText();
    	String newTitle = title.getText();
    	String relevent = relvance.getText();
    	//new matchers to see if any user input includes special characters
    	Matcher userHasSpecial = special.matcher(userStory);
    	Matcher titleHasSpecial = special.matcher(newTitle);
    	Matcher relevenceHasSpecial = special.matcher(relevent);
    	//Checks if anything is blank
    	if (userStory.isBlank() || newTitle.isBlank() || relevent.isBlank()) {
    		System.out.print("Missing Info");
    		missingInfo.setVisible(true);
    		isAccurate = false;
    	}
    	//checks if drop-downs are blank
    	else if(prolan.getValue() == null || appdomain.getValue() == null){
    		missingInfo.setVisible(true);
    		isAccurate = false;
    	}
    	//checks that user inputed a number 0-4
    	else{
    		switch (relevent) {
    		case ("0"):
    			isAccurate = true;
    			break;
    		case ("1"):
    			isAccurate = true;
    			break;
    		case ("2"):
    			isAccurate = true;
    			break;
    		case ("3"):
    			isAccurate = true;
    			break;
    		case ("4"):
    			isAccurate = true;
    			break;
    		default:
    			//sets error if number 0-4 was not inputed
    			relevenceErr.setVisible(true);
    			isAccurate = false;
    			break;
    		}
    		//Checks formating for user data, sending warning if incorrect
    		if (newTitle.length() < 5 || newTitle.length() > 20) {
    			titleErr.setVisible(true);
    			isAccurate = false;
    		}
    		
    		if (userStory.length() > 300 || userStory.length() < 50) {
    			userFormErr.setVisible(true);
    			System.out.print("Wrong length user \n");
    			isAccurate = false;
    		}
    		//checks that user story sections begin with the correct phrase
    		else if(userStory.toUpperCase().startsWith("AS A ") == false){
    			if(userStory.toUpperCase().startsWith("AS AN ") == false) {
    				userFormErr.setVisible(true);
        			System.out.print("Wrong start user \\n");
        			isAccurate = false;
    			}
    		}
    	}
    	//Checks if user inputs contain special characters
    	if(userHasSpecial.find() || titleHasSpecial.find() || relevenceHasSpecial.find()) {
			missingInfo.setVisible(false);
	    	userFormErr.setVisible(false);
	    	relevenceErr.setVisible(false);
			isAccurate = false;
			System.out.print("Special is used");
			specialErr.setVisible(true);
			errorCount ++;
		}
    	//kicks out user if they try to upload special characters five or more times
    	if (errorCount == 5) {
    		Main m = new Main();
    		m.changeScene("/LogInScreen.fxml");
    		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
    		//scene = new Scene(root);
    		//stage.setScene(scene);
    		//stage.show();
    	}
    	if (isAccurate == true){
	    	//writing info into text file
	    	ArrayList<String> data = new ArrayList<>();
	  
	    	data.add(title.getText());
	    	data.add(prolan.getValue());
	    	data.add(appdomain.getValue());			//adds the values from user input into a text file
	        data.add(relvance.getText());
	        data.add(descr.getText());
	        writeFile("UserStory.txt", data);
	        System.out.println ("Success"); //check		//done for testing purposes
	        descr.deleteText(0, userStory.length());
        	title.deleteText(0, newTitle.length());
        	relvance.deleteText(0, relevent.length());
        	prolan.setValue(null);
        	appdomain.setValue(null);;	
    	}
              

    }
    
	
    
    
	
}
